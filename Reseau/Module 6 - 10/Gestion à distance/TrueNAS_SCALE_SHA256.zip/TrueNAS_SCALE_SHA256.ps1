$fichier = "TrueNAS-SCALE-23.10.2.iso"
$val_sha = "c2b0d6ef6ca6a9bf53a0ee9c50f8d0461fd5f12b962a8800e95d0bc3ef629edb"
$algo    = "sha256"

$rep_SHA = (Get-FileHash -Path $fichier -Algorithm $algo).Hash

if ($rep_SHA -eq $val_sha)
{
  Write-Host "Le fichier '$fichier' est valide." -ForegroundColor Yellow
}
else
{
  Write-Host "Le fichier '$fichier' est invalide." -ForegroundColor Red
}
