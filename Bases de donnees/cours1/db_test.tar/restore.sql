--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "DB_TEST";
--
-- Name: DB_TEST; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "DB_TEST" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Canada.1252';


ALTER DATABASE "DB_TEST" OWNER TO postgres;

\connect "DB_TEST"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: employe; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employe (
    nas integer NOT NULL,
    nom character varying(32) NOT NULL,
    prenom character varying(32) NOT NULL,
    genre character(1) NOT NULL,
    date_embauche date NOT NULL,
    salaire numeric(5,2) NOT NULL,
    departement character varying(16),
    ville character varying(64) NOT NULL,
    superviseur integer,
    commission numeric(5,0)
);


ALTER TABLE public.employe OWNER TO postgres;

--
-- Data for Name: employe; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employe (nas, nom, prenom, genre, date_embauche, salaire, departement, ville, superviseur, commission) FROM stdin;
\.
COPY public.employe (nas, nom, prenom, genre, date_embauche, salaire, departement, ville, superviseur, commission) FROM '$$PATH$$/4776.dat';

--
-- PostgreSQL database dump complete
--

